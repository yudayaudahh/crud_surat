<li class="nav-item">
	<a href="<?php echo e(route('dashboard')); ?>">
		<i class="fas fa-home"></i>
		<p> Dashboard </p>
	</a>
</li>

<li class="nav-section">
	<h4 class="text-section"> Menu </h4>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('pegawai')); ?>">
        <i class="fas fa-address-book"></i>
        <p> Pegawai </p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('instasi')); ?>">
        <i class="fas fa-hotel"></i>
        <p> Instasi </p>
    </a>
</li>

<li class="nav-section">
	<span class="sidebar-mini-icon">
	<i class="fa fa-ellipsis-h"></i>
	</span>
	<h4 class="text-section"> Master Data </h4>
</li>

<li class="nav-item">
	<a href="<?php echo e(route('kategori')); ?>">
		<i class="fas fa-layer-group"></i>
		<p> Kategori </p>
	</a>
</li>

<li class="nav-item">
	<a href="<?php echo e(route('surat-masuk')); ?>">
		<i class="fas fa-book"></i>
		<p> Surat Masuk </p>
	</a>
</li>

<li class="nav-item">
	<a href="<?php echo e(route('surat-keluar')); ?>">
		<i class="fas fa-book-open"></i>
		<p> Surat Keluar </p>
	</a>
</li>

<li class="nav-section">
	<span class="sidebar-mini-icon">
	<i class="fa fa-ellipsis-h"></i>
	</span>
	<h4 class="text-section"> Lainnya </h4>
</li>

<li class="nav-item">
	<a href="<?php echo e(route('user')); ?>">
		<i class="fas fa-user"></i>
		<p> Akun </p>
	</a>
</li>

<li class="nav-item">
	<a href="<?php echo e(route('logout')); ?>">
		<i class="fas fa-sign-out-alt"></i>
		<p> Log out </p>
	</a>
</li>
<?php /**PATH C:\laragon\www\crud_surat\resources\views/layouts/menu/admin.blade.php ENDPATH**/ ?>