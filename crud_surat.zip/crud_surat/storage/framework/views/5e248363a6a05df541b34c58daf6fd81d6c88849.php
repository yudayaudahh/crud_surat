<?php if( auth()->user()->role  == 'admin'): ?>
	<?php echo $__env->make('layouts.menu.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
	<?php echo $__env->make('layouts.menu.pegawai', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\crud_surat\resources\views/layouts/menu.blade.php ENDPATH**/ ?>