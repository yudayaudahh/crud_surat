<!DOCTYPE html>
<html lang="en">

<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title> Arsip Surat </title>

	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<meta name="_token" content="<?php echo e(csrf_token()); ?>">
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="<?php echo e(url('img/icon_adiva.ico')); ?>" type="image/x-icon" />

	<link rel="stylesheet" href="<?php echo e(url('vendors/ladda/ladda-themeless.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(url('vendors/jquery-confirm/jquery-confirm.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(url('vendors/select2/select2.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(url('css/custom/select2-atlantis.css')); ?>">

	<script src="<?php echo e(url('js/plugin/webfont/webfont.min.js')); ?>"></script>
	<script>
		WebFont.load({
			google: {
				"families": ["Lato:300,400,700,900"]
			},
			custom: {
				"families": ["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands",
					"simple-line-icons"
				],
				urls: [`<?php echo e(url('css/fonts.min.css')); ?>`]
			},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>

	<!-- CSS Files -->
	<link rel="stylesheet" href="<?php echo e(url('css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(url('css/atlantis.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(url('css/custom/app.css')); ?>">

	<!-- <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css"> -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/css/iziToast.css" integrity="sha256-pODNVtK3uOhL8FUNWWvFQK0QoQoV3YA9wGGng6mbZ0E=" crossorigin="anonymous" />

	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link rel="stylesheet" href="<?php echo e(url('css/demo.css')); ?>">
	<style>
		.lo {
			margin: auto;
			position: absolute;
			margin-left: 50px;
		}

		.mh {
			width: 100px;
			height: 50px;
		}

		.card-title .btn,
		.card-title .btn:hover {
			color: white;
			padding: .4rem 1rem;
		}

		.banner-red {
			background-color: #e73939;
		}

		.edit:hover{
			background-color: greenyellow;
		}

		.delete:hover{
			background-color: greenyellow;
		}

		table.table-bordered.dataTable tbody td {
			vertical-align: top !important;
		}

		.page-link {
			z-index: 1;
			color: #fff;
			background-color: #e73939;
			border-color: #e73939;
		}

	</style>

	<?php echo $__env->yieldContent('styles'); ?>

</head>

<body>
	<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="wrapper">
		<div class="main-header">
			<!-- Logo Header -->
			
			<!-- End Logo Header -->

			<!-- Navbar Header -->
			<nav class="navbar navbar-header navbar-expand-lg" data-background-color="green2">

				<div class="container-fluid">
					<ul class="navbar-nav topbar-nav ml-md-auto align-items-center">
						<li class="nav-item toggle-nav-search hidden-caret">
							<a class="nav-link" data-toggle="collapse" href="#search-nav" role="button"
								aria-expanded="false" aria-controls="search-nav">
								<i class="fa fa-search"></i>
							</a>
						</li>
						<li class="nav-item dropdown hidden-caret">
							<a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#"
								aria-expanded="false">
								<div class="avatar-sm">
									<img src="<?php echo e(url('img/default-avatar.jpg')); ?>" alt="..."
										class="avatar-img rounded-circle">
							</a>
							<ul class="dropdown-menu dropdown-user animated fadeIn">
								<div class="dropdown-user-scroll scrollbar-outer">
									<li>
										<div class="user-box">
											<div class="avatar-lg"><img src="<?php echo e(url('img/default-avatar.jpg')); ?>"
													alt="..." class="avatar-img rounded"></div>
											<div class="u-text">
												<h4></h4>
												<p class="text-muted"></p><a
													href="#" class="btn btn-xs btn-secondary btn-sm">Lihat
													Profile</a>
											</div>
										</div>
									</li>
									<li>
										<div class="dropdown-divider"></div>
										<a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a>
									</li>
								</div>
							</ul>
						</li>
					</ul>
				</div>
			</nav>
			<!-- End Navbar -->
		</div>

		<!-- Sidebar -->
		
		<!-- End Sidebar -->

		<div class="main-panel">
			<div class="content">
				<?php if(isset($breadcrumbs)): ?>
				 <div class="page-inner">
					<div class="page-header">
						<h4 class="page-title"> <?php echo e($title ?? 'Judul'); ?> </h4>
						<ul class="breadcrumbs">
							<li class="nav-home">
								<a href="<?php echo e(url('dashboard')); ?>">
									<i class="flaticon-home"></i>
								</a>
							</li>

							<?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li class="separator">
									<i class="flaticon-right-arrow"></i>
								</li>
								<li class="nav-item">
									<a href="<?php echo e($breadcrumb['link']); ?>"> <?php echo e($breadcrumb['title']); ?> </a>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</ul>
					</div>

					<?php echo $__env->yieldContent('content'); ?>

				</div>
				<?php else: ?>
					<?php echo $__env->yieldContent('content'); ?>
				<?php endif; ?>
			</div>
		</div>

	</div>

	<?php echo $__env->yieldContent('modal'); ?>

	<!-- LIBARARY JS -->
	<script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>


	<!--   Core JS Files   -->

	
	<script src="<?php echo e(url('js/core/popper.min.js')); ?>"></script>
	<script src="<?php echo e(url('js/core/bootstrap.min.js')); ?>"></script>

	<!-- jQuery UI -->
	<script src="<?php echo e(url('js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js')); ?>"></script>
	<script src="<?php echo e(url('js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js')); ?>"></script>

	<!-- jQuery Scrollbar -->
	<script src="<?php echo e(url('js/plugin/jquery-scrollbar/jquery.scrollbar.min.js')); ?>"></script>


	<!-- Chart JS -->

	<!-- jQuery Sparkline -->
	<script src="<?php echo e(url('js/plugin/jquery.sparkline/jquery.sparkline.min.js')); ?>"></script>

	<!-- Chart Circle -->

	<!-- Datatables -->
	<script src="<?php echo e(url('js/plugin/datatables/datatables.min.js')); ?>"></script>

	<!-- Bootstrap Notify -->
	<script src="<?php echo e(url('js/plugin/bootstrap-notify/bootstrap-notify.min.js')); ?>"></script>

	<!-- jQuery Vector Maps -->

	<!-- Sweet Alert -->
	<script src="<?php echo e(url('js/plugin/sweetalert/sweetalert.min.js')); ?>"></script>

	<!-- Atlantis JS komen -->
	<script src="<?php echo e(url('js/atlantis.min.js')); ?>"></script>


	<script src="<?php echo e(url('vendors/ladda/spin.min.js')); ?>"></script>
	<script src="<?php echo e(url('vendors/ladda/ladda.min.js')); ?>"></script>
	<script src="<?php echo e(url('vendors/ladda/ladda.jquery.min.js')); ?>"></script>
	<script src="<?php echo e(url('vendors/jquery-confirm/jquery-confirm.js')); ?>"></script>
	<script src="<?php echo e(url('vendors/select2/select2.min.js')); ?>"></script>

	<script src="<?php echo e(url('js/myJs.js')); ?>"></script>

	<script type="text/javascript">
		const setActiveMenu = () => {
			let isFoundLink = false;
			let path = [];
			window.location.pathname.split("/").forEach(item => {
				if (item !== "") path.push(item);
			})
			let lengthPath = path.length;
			let lengthUse = lengthPath;
			let origin = window.location.origin;

			while (lengthUse >= 1) {
				let link = '';
				for (let i = 0; i < lengthUse; i++) {
					link += `/${path[i]}`;
				}
				$.each($('#menu-nav').find('a'), (i, elem) => {
					if ($(elem).attr('href') == `${origin}${link}`) {
						$(elem).parent(' ').addClass('active')
						$(elem).parents('li.nav-item').addClass('active').addClass('submenu')
						$(elem).parents('li.nav-item').find(`.collapse`).addClass('show')
					}
				})

				if (isFoundLink) break;
				lengthUse--;
			}
		}

		setActiveMenu();
	</script>

	<?php echo $__env->yieldContent('scripts'); ?>

</body>

</html>
<?php /**PATH C:\laragon\www\crud_surat\resources\views/layouts/template.blade.php ENDPATH**/ ?>